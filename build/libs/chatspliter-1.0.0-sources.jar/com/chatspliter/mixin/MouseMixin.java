package com.chatspliter.mixin;

import com.chatspliter.hud.ChatHudManager;
import net.minecraft.class_310;
import net.minecraft.class_312;
import net.minecraft.class_408;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Handle mouse clicks and scroll on filtered HUDs.
 * Only active in-game (no screen) or when chat is open.
 */
@Mixin(class_312.class)
public abstract class MouseMixin {

    @Unique
    private double sx() {
        var c = class_310.method_1551();
        return ((class_312) (Object) this).method_1603() / c.method_22683().method_4495();
    }

    @Unique
    private double sy() {
        var c = class_310.method_1551();
        return ((class_312) (Object) this).method_1604() / c.method_22683().method_4495();
    }

    @Unique
    private boolean shouldHandle() {
        var s = class_310.method_1551().field_1755;
        return s == null || s instanceof class_408;
    }

    @Inject(method = "onMouseButton", at = @At("HEAD"), cancellable = true)
    private void onMouseButton(long window, int button, int action, int mods, CallbackInfo ci) {
        if (!shouldHandle()) return;

        if (action == GLFW.GLFW_PRESS && button == 0) {
            if (ChatHudManager.getInstance().onMouseClick(sx(), sy(), button)) {
                ci.cancel();
            }
        } else if (action == GLFW.GLFW_RELEASE) {
            ChatHudManager.getInstance().onMouseRelease();
        }
    }

    @Inject(method = "onMouseScroll", at = @At("HEAD"), cancellable = true)
    private void onMouseScroll(long window, double horiz, double vert, CallbackInfo ci) {
        var client = class_310.method_1551();
        if (client.field_1755 instanceof class_408) {
            ChatHudManager.getInstance().onMouseScroll(sx(), sy(), vert);
        }
    }
}
