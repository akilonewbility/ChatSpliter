package com.chatspliter.mixin;

import com.chatspliter.ChatSpliterMod;
import com.chatspliter.hud.ChatHudManager;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public abstract class MinecraftClientMixin {

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        class_310 self = (class_310) (Object) this;
        try {
            ChatSpliterMod.onClientTick(self);
        } catch (Exception ignored) {}

        // Process HUD drag
        try {
            if (ChatHudManager.getInstance().isAnyDragging()) {
                double mx = self.field_1729.method_1603() / self.method_22683().method_4495();
                double my = self.field_1729.method_1604() / self.method_22683().method_4495();
                ChatHudManager.getInstance().onMouseDrag(mx, my);
            }
        } catch (Exception ignored) {}
    }
}
