package com.chatspliter.mixin;

import com.chatspliter.ChatSpliterMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import java.util.Arrays;
import net.minecraft.class_304;
import net.minecraft.class_315;

/**
 * Ensures our keybinding is in allKeys so it appears in the Controls screen.
 * No @Final on the shadow so the array can be replaced.
 */
@Mixin(class_315.class)
public abstract class GameOptionsMixin {

    @Shadow
    public class_304[] allKeys;

    @Inject(method = "load", at = @At("RETURN"))
    private void onLoad(CallbackInfo ci) {
        for (class_304 kb : allKeys) {
            if (kb == ChatSpliterMod.OPEN_CONFIG_KEY) return;
        }
        class_304[] arr = Arrays.copyOf(allKeys, allKeys.length + 1);
        arr[allKeys.length] = ChatSpliterMod.OPEN_CONFIG_KEY;
        allKeys = arr;
    }
}
