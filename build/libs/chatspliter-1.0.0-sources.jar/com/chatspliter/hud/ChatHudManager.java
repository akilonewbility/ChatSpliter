package com.chatspliter.hud;

import com.chatspliter.config.ChatSpliterConfig;
import com.chatspliter.config.FilterGroup;
import com.chatspliter.screen.GroupConfigScreen;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1041;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class ChatHudManager {
    private static ChatHudManager INSTANCE;
    private final List<FilteredChatHud> huds = new ArrayList<>();
    private final class_310 client;

    private ChatHudManager() { this.client = class_310.method_1551(); }

    public static ChatHudManager getInstance() {
        if (INSTANCE == null) INSTANCE = new ChatHudManager();
        return INSTANCE;
    }

    public void initialize() { syncFromConfig(); }

    public void syncFromConfig() {
        List<FilterGroup> groups = ChatSpliterConfig.getInstance().filterGroups;
        // Remove extra HUDs
        while (huds.size() > groups.size())
            huds.remove(huds.size() - 1);
        // Add missing HUDs
        while (huds.size() < groups.size())
            huds.add(new FilteredChatHud(groups.get(huds.size())));
        // Update config references for existing HUDs (preserves message history)
        for (int i = 0; i < huds.size(); i++)
            huds.get(i).replaceConfig(groups.get(i));
    }

    public List<FilteredChatHud> getHuds() { return huds; }

    public void onChatMessage(class_2561 message, int tickCounter) {
        if (!ChatSpliterConfig.getInstance().enabled) return;
        for (FilteredChatHud hud : huds) hud.addMessage(message, tickCounter);
    }

    public void render(class_332 context, int tickCounter) {
        if (!ChatSpliterConfig.getInstance().enabled || client.field_1724 == null) return;
        var w = client.method_22683();
        int sw = w.method_4486(), sh = w.method_4502();
        for (FilteredChatHud hud : huds) {
            hud.render(context, tickCounter, sw, sh,
                    g -> client.method_1507(new GroupConfigScreen(null, g)));
        }
    }

    public void refreshAll() { for (FilteredChatHud h : huds) h.refresh(); }

    // --------------- Drag interaction routing ---------------

    public FilteredChatHud getHudAt(double mx, double my) {
        var w = client.method_22683();
        for (FilteredChatHud h : huds)
            if (h.isMouseOver(mx, my, w.method_4486(), w.method_4502())) return h;
        return null;
    }

    public void onMouseScroll(double mx, double my, double amount) {
        FilteredChatHud h = getHudAt(mx, my);
        if (h != null) h.onScroll(amount);
    }

    public boolean onMouseClick(double mx, double my, int button) {
        if (button != 0) return false;
        FilteredChatHud h = getHudAt(mx, my);
        if (h == null) return false;
        var w = client.method_22683();
        int sw = w.method_4486(), sh = w.method_4502();
        int zone = h.getInteractionZone(mx, my, sw, sh);
        if (zone == 3) {
            // Settings button clicked
            client.method_1507(new GroupConfigScreen(null, h.getConfig()));
            return true;
        }
        if (zone > 0) {
            h.startDrag((int) mx, (int) my, zone, sw, sh);
            return true;
        }
        return false;
    }

    public boolean onMouseDrag(double mx, double my) {
        var w = client.method_22683();
        for (FilteredChatHud h : huds) {
            if (h.isDragging()) {
                h.onDrag((int) mx, (int) my, w.method_4486(), w.method_4502());
                return true;
            }
        }
        return false;
    }

    public void onMouseRelease() {
        for (FilteredChatHud h : huds) h.endDrag();
    }

    public boolean isAnyDragging() {
        for (FilteredChatHud h : huds) if (h.isDragging()) return true;
        return false;
    }
}
