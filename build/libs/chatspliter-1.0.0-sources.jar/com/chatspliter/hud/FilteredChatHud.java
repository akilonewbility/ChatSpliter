package com.chatspliter.hud;

import com.chatspliter.config.ChatSpliterConfig;
import com.chatspliter.config.FilterGroup;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_408;
import net.minecraft.class_5481;
import org.joml.Matrix3x2fStack;

public class FilteredChatHud {
    private static final long HISTORY_MS = 600_000;
    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH:mm:ss");

    public interface SettingsOpener {
        void openSettings(FilterGroup group);
    }

    private FilterGroup config;
    private final List<FilteredMessage> messages = new ArrayList<>();
    private final class_310 client;
    private int scrolledLines;

    // Settings button bounds (set during render)
    private int gearX, gearY, gearW, gearH;

    // Drag
    private boolean dragging, resizing;
    private int dsx, dsy, dox, doy, dow, doh;

    public FilteredChatHud(FilterGroup config) {
        this.config = config;
        this.client = class_310.method_1551();
    }

    public FilterGroup getConfig() { return config; }

    /** Update config reference without clearing message history */
    public void replaceConfig(FilterGroup newConfig) {
        this.config = newConfig;
    }

    public void addMessage(class_2561 message, int tickCounter) {
        if (!config.enabled || !config.matches(message.getString())) return;
        messages.add(new FilteredMessage(message.method_27661(), System.currentTimeMillis(),
                LocalTime.now().format(TIME_FMT)));
        while (messages.size() > config.maxLines * 2) messages.remove(0);
        scrolledLines = 0;
    }

    public void clear() { messages.clear(); scrolledLines = 0; }

    public void refresh() {
        long cutoff = System.currentTimeMillis() - HISTORY_MS;
        messages.removeIf(m -> m.receivedTime < cutoff);
        while (messages.size() > config.maxLines * 2) messages.remove(0);
    }

    // ==================== Render ====================

    public void render(class_332 ctx, int tickCounter, int sw, int sh, SettingsOpener opener) {
        if (!config.enabled) return;

        int x = class_3532.method_15340(config.x, 0, sw - config.width);
        int y = class_3532.method_15340(config.y, 0, sh - config.height);
        int w = config.width;
        int h = config.height;
        boolean chatOpen = isChatOpen();

        // Apply text scale via matrix transform
        float s = (float) config.scale;
        boolean useScale = s != 1.0f && s > 0.1f;
        if (useScale) {
            var mx = ctx.method_51448();
            mx.pushMatrix();
            mx.translate(x, y);
            mx.scale(s, s);
            mx.translate(-x, -y);
        }

        if (!messages.isEmpty()) renderMessages(ctx, x, y, w, h, useScale);

        if (useScale) {
            ctx.method_51448().popMatrix();
        }

        // Edit border + settings button (not scaled)
        if (chatOpen) {
            int b = 0x88FFCC00;
            ctx.method_25294(x, y, x + w, y + 1, b);
            ctx.method_25294(x, y + h - 1, x + w, y + h, b);
            ctx.method_25294(x, y, x + 1, y + h, b);
            ctx.method_25294(x + w - 1, y, x + w, y + h, b);
            ctx.method_25294(x + w - 8, y + h - 8, x + w, y + h, 0x66FFCC00);

            // Settings gear button (top-right corner)
            String gear = "⚙";
            int gw = client.field_1772.method_1727(gear) + 4;
            gearX = x + w - gw - 2;
            gearY = y + 3;
            gearW = gw;
            gearH = 11;
            ctx.method_25294(gearX, gearY, gearX + gearW, gearY + gearH, 0x66000000);
            ctx.method_27535(client.field_1772, class_2561.method_43470(gear),
                    gearX + 2, gearY + 1, 0xFFFFCC00);

            if (messages.isEmpty()) {
                String lbl = config.name;
                int lw = client.field_1772.method_1727(lbl);
                ctx.method_27535(client.field_1772, class_2561.method_43470(lbl),
                        x + (w - lw) / 2, y + h / 2 - 4, 0x88AAAAAA);
            }
        }

        // Title — always show when enabled and messages exist
        if (config.showTitle && !messages.isEmpty()) {
            String lbl = config.name;
            ctx.method_27535(client.field_1772, class_2561.method_43470(lbl),
                    x + w - client.field_1772.method_1727(lbl) - 4, y + 1, 0x55AAAAAA);
        }
    }

    private void renderMessages(class_332 ctx, int bx, int by, int w, int h, boolean scaled) {
        class_327 tr = client.field_1772;
        float s = (float) config.scale;
        int effW = scaled ? (int) (w / s) : w;
        int effH = scaled ? (int) (h / s) : h;
        int lh = 9 + config.lineSpacing;
        int pad = 2;
        int textW = effW - 4;
        if (textW <= 0 || lh <= 0) return;

        boolean chatOpen = isChatOpen();
        long now = System.currentTimeMillis();

        List<RenderLine> allLines = new ArrayList<>();
        for (FilteredMessage msg : messages) {
            class_2561 dt = msg.content;
            if (config.showTimestamp) dt = class_2561.method_43470("[" + msg.timestamp + "] ").method_10852(dt);
            for (class_5481 ot : tr.method_1728(dt, textW))
                allLines.add(new RenderLine(ot, msg.receivedTime));
        }
        if (allLines.isEmpty()) return;

        int total = allLines.size();
        int maxVis = effH / lh;
        if (maxVis <= 0) return;

        int start;
        if (chatOpen) {
            start = Math.max(0, total - maxVis - scrolledLines);
        } else {
            start = Math.max(0, total - maxVis);
            scrolledLines = 0;
        }
        int end = Math.min(total, start + maxVis);

        FilterGroup.ScrollDir dir = config.scrollDir;
        boolean rightAlign = config.textAlign == FilterGroup.TextAlign.RIGHT;
        boolean anchored = dir == FilterGroup.ScrollDir.TOP_ANCHORED;

        // Iteration: newest→oldest for BOTTOM_UP and TOP_DOWN; oldest→newest for TOP_ANCHORED
        int i = anchored ? start : (end - 1);
        int di = anchored ? 1 : -1;
        int n = 0;

        while (anchored ? (i < end) : (i >= start)) {
            RenderLine rl = allLines.get(i);
            long ageMs = now - rl.receivedTime;
            int alpha = chatOpen ? 255 : calcFade(ageMs);

            // TOP_ANCHORED: skip fully faded lines, they don't take space
            if (anchored && alpha <= 2) { i += di; continue; }

            int lineY;
            if (dir == FilterGroup.ScrollDir.BOTTOM_UP) {
                lineY = by + effH - pad - lh - n * lh;
                if (lineY < by) break;
            } else {
                lineY = by + pad + n * lh;
                if (lineY + lh > by + effH) break;
            }

            if (alpha > 2) {
                int tw = tr.method_30880(rl.text);
                int textX = rightAlign ? (bx + effW - 2 - tw) : (bx + 2);
                int bgL = rightAlign ? Math.max(bx + 1, bx + effW - 2 - tw - 2) : (bx + 1);
                int bgR = rightAlign ? (bx + effW - 1) : Math.min(bx + effW - 1, bx + 1 + tw + 4);

                int bgA = (int) (config.opacity * alpha * 0.7) & 0xFF;
                if (bgA > 10)
                    ctx.method_25294(bgL, lineY - 1, bgR, lineY + lh - 1, (bgA << 24) | (config.backgroundColor & 0x00FFFFFF));

                int tc = config.textColor & 0x00FFFFFF;
                int ma = (int) (config.textOpacity * alpha) & 0xFF;
                ctx.method_35720(tr, rl.text, textX, lineY, (ma << 24) | tc);
            }
            n++;
            if (n >= maxVis) break;
            i += di;
        }
    }

    private int calcFade(long ageMs) {
        double ageSec = ageMs / 1000.0;
        double total = config.displayTime;
        double fade = config.fadeTime;
        if (fade <= 0 || total <= 0) return ageSec < total ? 255 : 0;
        double fullSec = Math.max(0, total - fade);
        if (ageSec < fullSec) return 255;
        if (ageSec >= total) return 0;
        return (int) (255 * (1.0 - (ageSec - fullSec) / fade));
    }

    // ==================== Mouse ====================

    public boolean isMouseOver(double mx, double my, int sw, int sh) {
        int x = class_3532.method_15340(config.x, 0, sw - config.width);
        int y = class_3532.method_15340(config.y, 0, sh - config.height);
        return mx >= x && mx <= x + config.width && my >= y && my <= y + config.height;
    }

    public boolean isOverSettingsButton(double mx, double my) {
        return mx >= gearX && mx <= gearX + gearW && my >= gearY && my <= gearY + gearH;
    }

    public int getInteractionZone(double mx, double my, int sw, int sh) {
        int x = class_3532.method_15340(config.x, 0, sw - config.width);
        int y = class_3532.method_15340(config.y, 0, sh - config.height);
        if (mx < x || mx > x + config.width || my < y || my > y + config.height) return 0;
        if (isOverSettingsButton(mx, my)) return 3; // settings button
        if (mx > x + config.width - 12 && my > y + config.height - 12) return 2; // resize
        return 1; // move
    }

    public void startDrag(int mx, int my, int zone, int sw, int sh) {
        dragging = zone == 1; resizing = zone == 2;
        dsx = mx; dsy = my; dox = config.x; doy = config.y;
        dow = config.width; doh = config.height;
    }

    public void onDrag(int mx, int my, int sw, int sh) {
        if (dragging) {
            config.x = class_3532.method_15340(dox + (mx - dsx), 0, sw - config.width);
            config.y = class_3532.method_15340(doy + (my - dsy), 0, sh - config.height);
        } else if (resizing) {
            config.width = class_3532.method_15340(dow + (mx - dsx), 60, sw - config.x);
            config.height = class_3532.method_15340(doh + (my - dsy), 40, sh - config.y);
        }
    }

    public void endDrag() {
        if (dragging || resizing) { ChatSpliterConfig.getInstance().save(); dragging = false; resizing = false; }
    }

    public boolean isDragging() { return dragging || resizing; }

    public void onScroll(double amount) {
        int maxS = Math.max(0, messages.size() - 1);
        scrolledLines = class_3532.method_15340(scrolledLines + (int) amount, 0, maxS);
    }

    private boolean isChatOpen() { return client.field_1755 instanceof class_408; }

    private record FilteredMessage(class_2561 content, long receivedTime, String timestamp) {}
    private record RenderLine(class_5481 text, long receivedTime) {}
}
