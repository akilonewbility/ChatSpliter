package com.chatspliter.screen;

import com.chatspliter.config.FilterGroup;
import com.chatspliter.config.MatchMode;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5676;
import net.minecraft.class_7842;

public class GroupConfigScreen extends class_437 {
    private static final int HEADER_H = 26;
    private static final int FOOTER_H = 38;
    private static final int ROW_H = 22;
    private static final int LEFT = 10;
    private static final int RIGHT = 160;

    private final class_437 parent;
    private final FilterGroup group;

    // Working copies
    private int x, y, w, h, ls, ml;
    private double sc, dt, ft, op, to;
    private int scrollY, maxScrollY;

    // Tooltip mapping: rowY -> tooltip translation key
    private final Map<Integer, String> tooltips = new LinkedHashMap<>();

    public GroupConfigScreen(class_437 parent, FilterGroup g) {
        super(class_2561.method_43470(g.name));
        this.parent = parent;
        this.group = g;
        x = g.x; y = g.y; w = g.width; h = g.height;
        sc = g.scale; dt = g.displayTime; ft = g.fadeTime;
        op = g.opacity; to = g.textOpacity; ls = g.lineSpacing; ml = g.maxLines;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        tooltips.clear();

        int viewH = this.field_22790 - HEADER_H - FOOTER_H;
        int totalRows = 22, contentH = totalRows * ROW_H;
        maxScrollY = Math.max(0, contentH - viewH);
        scrollY = class_3532.method_15340(scrollY, 0, maxScrollY);

        int ry = HEADER_H - scrollY;

        // Name
        addLabel(ry, "chatspliter.filter_group.name", "chatspliter.tooltip.name");
        class_342 nf = new class_342(field_22793, RIGHT, ry, 160, 20, class_2561.method_43473());
        nf.method_1880(64);
        nf.method_1852(group.name); nf.method_1863(v -> group.name = v);
        method_37063(nf);
        ry += ROW_H;

        // Keywords
        addLabel(ry, "chatspliter.filter_group.keywords", "chatspliter.tooltip.keywords");
        int kwW = Math.max(260, this.field_22789 - RIGHT - 10);
        class_342 kf = new class_342(field_22793, RIGHT, ry, kwW, 20, class_2561.method_43473());
        kf.method_1880(1024);
        kf.method_1852(String.join(", ", group.keywords));
        kf.method_1863(v -> { group.keywords.clear(); for (String s : v.split(",")) { String t = s.trim(); if (!t.isEmpty()) group.keywords.add(t); }});
        method_37063(kf);
        ry += ROW_H;

        // Match mode
        addLabel(ry, "chatspliter.filter_group.match_mode", "chatspliter.tooltip.match_mode");
        method_37063(class_5676.<MatchMode>method_32606(m -> class_2561.method_43471(m.getTranslationKey()))
                .method_32624(MatchMode.values()).method_32619(group.matchMode)
                .method_32617(RIGHT, ry, 120, 20, class_2561.method_43473(), (btn, v) -> group.matchMode = v));
        ry += ROW_H;

        // Case sensitive
        method_37063(class_5676.method_32613(group.caseSensitive)
                .method_32617(RIGHT, ry, 120, 20, class_2561.method_43471("chatspliter.filter_group.case_sensitive"),
                        (btn, v) -> group.caseSensitive = v));
        ry += ROW_H;

        // Enabled
        method_37063(class_5676.method_32613(group.enabled)
                .method_32617(RIGHT, ry, 120, 20, class_2561.method_43471("chatspliter.config.enabled"),
                        (btn, v) -> group.enabled = v));
        ry += ROW_H;

        ry = addInt("chatspliter.filter_group.x", x, 0, 3840, 10, ry, v -> { x=v; group.x=v; }, "chatspliter.tooltip.x");
        ry = addInt("chatspliter.filter_group.y", y, 0, 2160, 10, ry, v -> { this.y=v; group.y=v; }, "chatspliter.tooltip.y");
        ry = addInt("chatspliter.filter_group.width", w, 60, 1920, 10, ry, v -> { this.w=v; group.width=v; }, "chatspliter.tooltip.width");
        ry = addInt("chatspliter.filter_group.height", h, 40, 1080, 10, ry, v -> { this.h=v; group.height=v; }, "chatspliter.tooltip.height");
        ry = addDbl("chatspliter.filter_group.scale", sc, 0.25, 4.0, 0.05, ry, v -> { sc=v; group.scale=v; }, "chatspliter.tooltip.scale");
        ry = addDbl("chatspliter.filter_group.display_time", dt, 0.5, 60.0, 0.5, ry, v -> { dt=v; group.displayTime=v; }, "chatspliter.tooltip.display_time");
        ry = addDbl("chatspliter.filter_group.fade_time", ft, 0.0, 30.0, 0.5, ry, v -> { ft=v; group.fadeTime=v; }, "chatspliter.tooltip.fade_time");
        ry = addDbl("chatspliter.filter_group.opacity", op, 0.0, 1.0, 0.05, ry, v -> { op=v; group.opacity=v; }, "chatspliter.tooltip.opacity");
        ry = addDbl("chatspliter.filter_group.text_opacity", to, 0.0, 1.0, 0.05, ry, v -> { to=v; group.textOpacity=v; }, "chatspliter.tooltip.text_opacity");
        ry = addInt("chatspliter.filter_group.line_spacing", ls, -5, 10, 1, ry, v -> { ls=v; group.lineSpacing=v; }, "chatspliter.tooltip.line_spacing");
        ry = addInt("chatspliter.filter_group.max_lines", ml, 10, 500, 10, ry, v -> { ml=v; group.maxLines=v; }, "chatspliter.tooltip.max_lines");

        method_37063(class_5676.method_32613(group.showTimestamp)
                .method_32617(RIGHT, ry, 120, 20, class_2561.method_43471("chatspliter.filter_group.show_timestamp"),
                        (btn, v) -> group.showTimestamp = v));
        ry += ROW_H;

        // Show title
        method_37063(class_5676.method_32613(group.showTitle)
                .method_32617(RIGHT, ry, 120, 20, class_2561.method_43471("chatspliter.filter_group.show_title"),
                        (btn, v) -> group.showTitle = v));
        ry += ROW_H;

        // Text align
        method_37063(class_5676.<FilterGroup.TextAlign>method_32606(
                        a -> class_2561.method_43471("chatspliter.filter_group.text_align." + a.name().toLowerCase()))
                .method_32624(FilterGroup.TextAlign.values()).method_32619(group.textAlign)
                .method_32617(RIGHT, ry, 120, 20, class_2561.method_43473(),
                        (btn, v) -> group.textAlign = v));
        ry += ROW_H;

        // Scroll direction
        method_37063(class_5676.<FilterGroup.ScrollDir>method_32606(
                        a -> class_2561.method_43471("chatspliter.filter_group.scroll_dir." + a.name().toLowerCase()))
                .method_32624(FilterGroup.ScrollDir.values()).method_32619(group.scrollDir)
                .method_32617(RIGHT, ry, 120, 20, class_2561.method_43473(),
                        (btn, v) -> group.scrollDir = v));

        // Footer buttons
        int btnY = this.field_22790 - 26;
        method_37063(class_4185.method_46430(class_2561.method_43471("chatspliter.button.done"), btn -> method_25419())
                .method_46434(this.field_22789 - 160, btnY, 70, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43471("chatspliter.button.cancel"), btn -> method_25419())
                .method_46434(this.field_22789 - 80, btnY, 70, 20).method_46431());
    }

    private void addLabel(int ry, String key, String tip) {
        method_37063(new class_7842(LEFT, ry + 6, 140, 12, class_2561.method_43471(key), field_22793));
        tooltips.put(ry, tip);
    }

    private int addInt(String key, int val, int min, int max, int step, int ry, java.util.function.IntConsumer set, String tip) {
        addLabel(ry, key, tip);
        final int cv = val;
        addBtn(class_2561.method_43470(" - "), RIGHT, ry, 22, () -> { set.accept(class_3532.method_15340(cv - step, min, max)); rebuild(); });
        method_37063(new class_7842(RIGHT + 30, ry + 6, 60, 12, class_2561.method_43470(String.valueOf(val)), field_22793));
        addBtn(class_2561.method_43470(" + "), RIGHT + 80, ry, 22, () -> { set.accept(class_3532.method_15340(cv + step, min, max)); rebuild(); });
        return ry + ROW_H;
    }

    private int addDbl(String key, double val, double min, double max, double step, int ry, java.util.function.DoubleConsumer set, String tip) {
        addLabel(ry, key, tip);
        final double cv = val;
        addBtn(class_2561.method_43470(" - "), RIGHT, ry, 22, () -> { set.accept(Math.round(class_3532.method_15350(cv - step, min, max) * 100.0) / 100.0); rebuild(); });
        method_37063(new class_7842(RIGHT + 30, ry + 6, 60, 12, class_2561.method_43470(String.format("%.2f", val)), field_22793));
        addBtn(class_2561.method_43470(" + "), RIGHT + 80, ry, 22, () -> { set.accept(Math.round(class_3532.method_15350(cv + step, min, max) * 100.0) / 100.0); rebuild(); });
        return ry + ROW_H;
    }

    private void addBtn(class_2561 text, int bx, int by, int bw, Runnable action) {
        method_37063(class_4185.method_46430(text, btn -> action.run()).method_46434(bx, by, bw, 20).method_46431());
    }

    @Override
    public boolean method_25401(double mx, double my, double hz, double vt) {
        if (maxScrollY > 0) { scrollY = class_3532.method_15340(scrollY - (int)(vt * 12), 0, maxScrollY); rebuild(); return true; }
        return super.method_25401(mx, my, hz, vt);
    }

    @Override
    public void method_25394(class_332 ctx, int mx, int my, float delta) {
        super.method_25394(ctx, mx, my, delta);
        ctx.method_27534(field_22793, class_2561.method_43470("§l" + group.name), this.field_22789 / 2, 6, 0xFFFFFF);

        // Scrollbar
        if (maxScrollY > 0) {
            int vh = this.field_22790 - HEADER_H - FOOTER_H;
            int bh = Math.max(16, vh * vh / (22 * ROW_H));
            int by = HEADER_H + (vh - bh) * scrollY / maxScrollY;
            ctx.method_25294(this.field_22789 - 3, by, this.field_22789 - 1, by + bh, 0x88AAAAAA);
        }

        // Tooltip: find which row the mouse is on
        for (var entry : tooltips.entrySet()) {
            int rowTop = entry.getKey();
            if (mx >= LEFT && mx <= this.field_22789 - 10 && my >= rowTop && my < rowTop + ROW_H) {
                ctx.method_51438(field_22793, class_2561.method_43471(entry.getValue()), mx, my);
                break;
            }
        }
    }

    private void rebuild() { method_37067(); method_25426(); }

    @Override public void method_25419() { field_22787.method_1507(parent); }
}
