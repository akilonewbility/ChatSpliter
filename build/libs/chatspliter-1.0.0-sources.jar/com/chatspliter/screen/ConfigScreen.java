package com.chatspliter.screen;

import com.chatspliter.config.ChatSpliterConfig;
import com.chatspliter.config.FilterGroup;
import com.chatspliter.hud.ChatHudManager;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5676;
import net.minecraft.class_7842;

public class ConfigScreen extends class_437 {
    private final class_437 parent;
    private final ChatSpliterConfig config;
    private final List<FilterGroup> workingGroups;

    private class_5676<Boolean> enabledButton;
    private class_5676<Boolean> hideMatchedButton;

    public ConfigScreen(class_437 parent) {
        super(class_2561.method_43471("chatspliter.config.title"));
        this.parent = parent;
        this.config = ChatSpliterConfig.getInstance();
        this.workingGroups = new ArrayList<>();
        for (FilterGroup g : config.filterGroups) {
            this.workingGroups.add(g.copy());
        }
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        int centerX = this.field_22789 / 2;

        method_37063(new class_7842(centerX - 80, 8, 160, 20,
                class_2561.method_43471("chatspliter.config.title"), field_22793).method_48597());

        enabledButton = class_5676.method_32613(config.enabled)
                .method_32617(10, 32, 150, 20,
                        class_2561.method_43471("chatspliter.config.enabled"),
                        (btn, val) -> {});
        method_37063(enabledButton);

        hideMatchedButton = class_5676.method_32613(config.hideMatchedFromMain)
                .method_32617(10, 56, 220, 20,
                        class_2561.method_43471("chatspliter.config.hide_matched_from_main"),
                        (btn, val) -> {});
        method_37063(hideMatchedButton);

        method_37063(new class_7842(10, 84, 200, 12,
                class_2561.method_43471("chatspliter.config.filter_groups"), field_22793));

        int y = 100;
        int maxVisible = Math.min(workingGroups.size(), (this.field_22790 - 170) / 30);

        for (int i = 0; i < maxVisible; i++) {
            final int index = i;
            FilterGroup group = workingGroups.get(i);

            String statusIcon = group.enabled ? "§a●" : "§7○";
            method_37063(new class_7842(14, y + 6, 200, 12,
                    class_2561.method_43470(statusIcon + " " + group.name + "  §7[" + group.keywords.size() + " kw]"),
                    field_22793));

            method_37063(class_4185.method_46430(
                            class_2561.method_43470("⚙"),
                            btn -> openGroupEditor(index))
                    .method_46434(this.field_22789 - 90, y, 20, 20).method_46431());

            method_37063(class_4185.method_46430(
                            class_2561.method_43470("✕"),
                            btn -> removeGroup(index))
                    .method_46434(this.field_22789 - 65, y, 20, 20).method_46431());

            y += 28;
        }

        int buttonY = this.field_22790 - 28;

        method_37063(class_4185.method_46430(
                        class_2561.method_43471("chatspliter.button.add_group"),
                        btn -> addGroup())
                .method_46434(10, buttonY, 120, 20).method_46431());

        method_37063(class_4185.method_46430(
                        class_2561.method_43471("chatspliter.button.reset"),
                        btn -> resetDefaults())
                .method_46434(135, buttonY, 75, 20).method_46431());

        method_37063(class_4185.method_46430(
                        class_2561.method_43471("chatspliter.button.done"),
                        btn -> saveAndClose())
                .method_46434(this.field_22789 - 160, buttonY, 70, 20).method_46431());

        method_37063(class_4185.method_46430(
                        class_2561.method_43471("chatspliter.button.cancel"),
                        btn -> method_25419())
                .method_46434(this.field_22789 - 80, buttonY, 70, 20).method_46431());
    }

    private void openGroupEditor(int index) {
        if (index >= 0 && index < workingGroups.size()) {
            field_22787.method_1507(new GroupConfigScreen(this, workingGroups.get(index)));
        }
    }

    private void addGroup() {
        FilterGroup newGroup = new FilterGroup("Group " + (workingGroups.size() + 1));
        workingGroups.add(newGroup);
        method_37067();
        method_25426();
    }

    private void removeGroup(int index) {
        if (index >= 0 && index < workingGroups.size()) {
            workingGroups.remove(index);
            method_37067();
            method_25426();
        }
    }

    private void saveAndClose() {
        config.enabled = enabledButton.method_32603();
        config.hideMatchedFromMain = hideMatchedButton.method_32603();

        // Update in-place: keep existing FilterGroup objects so HUDs retain history
        while (config.filterGroups.size() > workingGroups.size())
            config.filterGroups.remove(config.filterGroups.size() - 1);
        for (int i = 0; i < workingGroups.size(); i++) {
            FilterGroup src = workingGroups.get(i);
            if (i < config.filterGroups.size()) {
                copyInto(src, config.filterGroups.get(i));
            } else {
                config.filterGroups.add(src.copy());
            }
        }
        config.save();
        ChatHudManager.getInstance().syncFromConfig();
        method_25419();
    }

    private void copyInto(FilterGroup src, FilterGroup dst) {
        dst.name = src.name;
        dst.enabled = src.enabled;
        dst.keywords.clear(); dst.keywords.addAll(src.keywords);
        dst.matchMode = src.matchMode;
        dst.x = src.x; dst.y = src.y;
        dst.width = src.width; dst.height = src.height;
        dst.scale = src.scale;
        dst.displayTime = src.displayTime;
        dst.fadeTime = src.fadeTime;
        dst.opacity = src.opacity;
        dst.textOpacity = src.textOpacity;
        dst.lineSpacing = src.lineSpacing;
        dst.showTimestamp = src.showTimestamp;
        dst.maxLines = src.maxLines;
        dst.showTitle = src.showTitle;
    }

    private void resetDefaults() {
        config.reset();
        workingGroups.clear();
        for (FilterGroup g : config.filterGroups) {
            workingGroups.add(g.copy());
        }
        method_25426();
    }

    @Override
    public void method_25419() {
        field_22787.method_1507(parent);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_27535(field_22793,
                class_2561.method_43470(workingGroups.size() + " groups"),
                this.field_22789 - 100, 86, 0x666666);
    }
}
