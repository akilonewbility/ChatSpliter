package com.chatspliter;

import com.chatspliter.config.ChatSpliterConfig;
import com.chatspliter.hud.ChatHudManager;
import com.chatspliter.screen.ConfigScreen;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ChatSpliterMod implements ClientModInitializer {
    public static final String MOD_ID = "chatspliter";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static final class_304 OPEN_CONFIG_KEY = new class_304(
            "chatspliter.key.open_config",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_K,
            "key.categories.misc"
    );

    @Override
    public void onInitializeClient() {
        LOGGER.info("[ChatSpliter] Initializing...");
        ChatSpliterConfig.getInstance();
        ChatHudManager.getInstance().initialize();
        LOGGER.info("[ChatSpliter] Initialized successfully! Press K to open config.");
    }

    /**
     * Called from MinecraftClientMixin each tick to check key presses.
     */
    public static void onClientTick(class_310 client) {
        if (client.field_1724 == null) return;
        while (OPEN_CONFIG_KEY.method_1436()) {
            client.method_1507(new ConfigScreen(null));
        }
    }
}
